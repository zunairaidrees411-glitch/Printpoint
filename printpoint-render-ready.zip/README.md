# PrintPoint

An online print and photocopy ordering platform. Students place orders with their files, and each shop registers itself and sees only its own orders.

## Features
- **Role chosen at signup:** "I am a student" or "I own a shop". No administrator approval is needed.
- **Students:** choose a shop, upload a file, set pages, copies, colour, sides and paper size, see a live price estimate, track order status, and cancel pending orders. Students only see their own orders.
- **Shops:** set the shop name, location and per-page B&W and colour prices. The dashboard shows today's orders, pending and ready counts, today's sales, orders by department, a seven-day chart and an incoming-orders table with file download and status updates. A shop only sees its own data.
- A shop cannot see another shop's orders or files.

## Run on Replit
1. Create a new **Python** Repl and upload every file in this folder (`app.py`, `requirements.txt`, `.replit`, `templates/`, `static/`).
2. Add a secret named `SECRET_KEY` with a long random value (Tools, then Secrets).
3. Press **Run**. The app listens on port 8080 (override with the `PORT` environment variable).
4. Renaming the Repl changes the link, for example `project-name.username.replit.app`.

## Run on your computer
```
python -m pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:8080 in a browser.

## Notes
- Data is stored in `printpoint.db` (SQLite) and uploaded files in `uploads/`. On Replit Autoscale deployments local files may be lost on restart, so use a Reserved VM deployment or an external database and object storage.
- Password reset is not implemented yet.
- Always set `SECRET_KEY` before deploying.
