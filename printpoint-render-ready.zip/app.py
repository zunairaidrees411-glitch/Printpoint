import os
import sqlite3
import uuid
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template,
                   request, send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "printpoint.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_EXT = {"pdf", "doc", "docx", "ppt", "pptx", "txt", "jpg", "jpeg", "png"}
DEPARTMENTS = [
    "Computer Science", "Software Engineering", "Electrical Engineering",
    "Business Administration", "Mathematics", "Hostel", "Library", "Other",
]
STATUSES = ["Pending", "Printing", "Ready", "Collected", "Cancelled"]
PAPER_SIZES = ["A4", "A3", "Legal"]

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-in-production")
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20 MB


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS shops (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            location TEXT,
            price_bw REAL NOT NULL DEFAULT 3,
            price_color REAL NOT NULL DEFAULT 15
        );
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student','shop')),
            shop_id INTEGER REFERENCES shops(id)
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL REFERENCES users(id),
            shop_id INTEGER NOT NULL REFERENCES shops(id),
            filename TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            pages INTEGER NOT NULL,
            copies INTEGER NOT NULL,
            color TEXT NOT NULL,
            sides TEXT NOT NULL,
            paper TEXT NOT NULL,
            department TEXT NOT NULL,
            notes TEXT,
            total REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pending',
            created_at TEXT NOT NULL
        );
        """
    )
    db.commit()
    db.close()


# ------------------------------------------------------------------ auth
@app.before_request
def load_user():
    g.user = None
    uid = session.get("user_id")
    if uid:
        g.user = get_db().execute(
            "SELECT * FROM users WHERE id=?", (uid,)).fetchone()


def login_required(role=None):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            if g.user is None:
                return redirect(url_for("login", next=request.path))
            if role and g.user["role"] != role:
                abort(403)
            return fn(*a, **kw)
        return wrapper
    return deco


@app.route("/")
def index():
    if g.user:
        if g.user["role"] == "shop":
            return redirect(url_for("shop_dashboard"))
        return redirect(url_for("my_orders"))
    return render_template("home.html")


def parse_price(value):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    return v if 0 <= v <= 1000 else None


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("index"))
    role = request.values.get("role", "student")
    if role not in ("student", "shop"):
        role = "student"
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        shop_name = request.form.get("shop_name", "").strip()
        location = request.form.get("location", "").strip()
        bw = parse_price(request.form.get("price_bw"))
        color = parse_price(request.form.get("price_color"))

        error = None
        if not name or "@" not in email or len(pw) < 6:
            error = "Please enter your name, a valid email address and a password of at least 6 characters."
        elif role == "shop" and (not shop_name or bw is None or color is None):
            error = "Please enter the shop name and the per-page prices for B&W and Color."
        if error:
            flash(error, "error")
        else:
            db = get_db()
            try:
                shop_id = None
                if role == "shop":
                    cur = db.execute(
                        "INSERT INTO shops(name, location, price_bw, price_color) VALUES (?,?,?,?)",
                        (shop_name, location, bw, color))
                    shop_id = cur.lastrowid
                db.execute(
                    "INSERT INTO users(name,email,password_hash,role,shop_id) VALUES (?,?,?,?,?)",
                    (name, email, generate_password_hash(pw), role, shop_id))
                db.commit()
                flash("Your account has been created. Please log in.", "ok")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                db.rollback()
                flash("This email address is already registered.", "error")
    return render_template("register.html", role=role)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        user = get_db().execute(
            "SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], pw):
            session.clear()
            session["user_id"] = user["id"]
            nxt = request.args.get("next")
            if nxt and nxt.startswith("/"):
                return redirect(nxt)
            return redirect(url_for("index"))
        flash("Incorrect email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


# --------------------------------------------------------------- student
def calc_total(shop, pages, copies, color):
    rate = shop["price_color"] if color == "Color" else shop["price_bw"]
    return round(rate * pages * copies, 2)


@app.route("/order/new", methods=["GET", "POST"])
@login_required("student")
def new_order():
    db = get_db()
    shops = db.execute("SELECT * FROM shops ORDER BY name").fetchall()
    if request.method == "POST":
        f = request.files.get("file")
        try:
            shop_id = int(request.form.get("shop_id", 0))
            pages = int(request.form.get("pages", 0))
            copies = int(request.form.get("copies", 0))
        except ValueError:
            shop_id = pages = copies = 0
        color = request.form.get("color", "B&W")
        sides = request.form.get("sides", "Single")
        paper = request.form.get("paper", "A4")
        dept = request.form.get("department", "Other")
        notes = request.form.get("notes", "").strip()[:500]
        shop = db.execute("SELECT * FROM shops WHERE id=?", (shop_id,)).fetchone()

        error = None
        if not f or not f.filename:
            error = "Please select a file."
        elif f.filename.rsplit(".", 1)[-1].lower() not in ALLOWED_EXT:
            error = "This file type is not allowed (pdf, doc, docx, ppt, pptx, txt, jpg, png)."
        elif shop is None:
            error = "Please select a shop."
        elif not (1 <= pages <= 2000) or not (1 <= copies <= 500):
            error = "Pages must be between 1 and 2000, and copies between 1 and 500."
        elif color not in ("B&W", "Color") or sides not in ("Single", "Double") \
                or paper not in PAPER_SIZES or dept not in DEPARTMENTS:
            error = "One or more form values are invalid."
        if error:
            flash(error, "error")
        else:
            original = secure_filename(f.filename) or "file"
            stored = uuid.uuid4().hex + "_" + original
            f.save(os.path.join(UPLOAD_DIR, stored))
            total = calc_total(shop, pages, copies, color)
            db.execute(
                "INSERT INTO orders(student_id,shop_id,filename,stored_name,pages,copies,"
                "color,sides,paper,department,notes,total,created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (g.user["id"], shop_id, original, stored, pages, copies, color,
                 sides, paper, dept, notes, total,
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            db.commit()
            flash("Your order has been placed. You can track its status below.", "ok")
            return redirect(url_for("my_orders"))
    return render_template("new_order.html", shops=shops,
                           departments=DEPARTMENTS, papers=PAPER_SIZES)


@app.route("/orders")
@login_required("student")
def my_orders():
    rows = get_db().execute(
        "SELECT o.*, s.name AS shop_name FROM orders o JOIN shops s ON s.id=o.shop_id "
        "WHERE o.student_id=? ORDER BY o.id DESC", (g.user["id"],)).fetchall()
    return render_template("my_orders.html", orders=rows)


@app.route("/orders/<int:oid>/cancel", methods=["POST"])
@login_required("student")
def cancel_order(oid):
    db = get_db()
    o = db.execute("SELECT * FROM orders WHERE id=? AND student_id=?",
                   (oid, g.user["id"])).fetchone()
    if o is None:
        abort(404)
    if o["status"] == "Pending":
        db.execute("UPDATE orders SET status='Cancelled' WHERE id=?", (oid,))
        db.commit()
        flash("Your order has been cancelled.", "ok")
    else:
        flash("Only pending orders can be cancelled.", "error")
    return redirect(url_for("my_orders"))


# ------------------------------------------------------------------ shop
def shop_stats(shop_id):
    db = get_db()
    today = datetime.now().strftime("%Y-%m-%d")
    one = lambda q, *a: db.execute(q, a).fetchone()[0]
    stats = {
        "today_orders": one(
            "SELECT COUNT(*) FROM orders WHERE shop_id=? AND created_at LIKE ?",
            shop_id, today + "%"),
        "pending": one(
            "SELECT COUNT(*) FROM orders WHERE shop_id=? AND status='Pending'", shop_id),
        "ready": one(
            "SELECT COUNT(*) FROM orders WHERE shop_id=? AND status='Ready'", shop_id),
        "today_revenue": one(
            "SELECT COALESCE(SUM(total),0) FROM orders WHERE shop_id=? "
            "AND created_at LIKE ? AND status!='Cancelled'", shop_id, today + "%"),
        "total_orders": one("SELECT COUNT(*) FROM orders WHERE shop_id=?", shop_id),
    }
    return stats


@app.route("/shop")
@login_required("shop")
def shop_dashboard():
    db = get_db()
    sid = g.user["shop_id"]
    shop = db.execute("SELECT * FROM shops WHERE id=?", (sid,)).fetchone()
    status = request.args.get("status", "")
    q = ("SELECT o.*, u.name AS student_name, u.email AS student_email "
         "FROM orders o JOIN users u ON u.id=o.student_id WHERE o.shop_id=?")
    args = [sid]
    if status in STATUSES:
        q += " AND o.status=?"
        args.append(status)
    q += " ORDER BY CASE o.status WHEN 'Pending' THEN 0 WHEN 'Printing' THEN 1 " \
         "WHEN 'Ready' THEN 2 ELSE 3 END, o.id DESC LIMIT 200"
    orders = db.execute(q, args).fetchall()

    by_dept = db.execute(
        "SELECT department, COUNT(*) AS n FROM orders WHERE shop_id=? "
        "AND status!='Cancelled' GROUP BY department ORDER BY n DESC", (sid,)).fetchall()
    max_dept = max([r["n"] for r in by_dept], default=1)

    days = []
    for i in range(6, -1, -1):
        d = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
        n = db.execute(
            "SELECT COUNT(*) FROM orders WHERE shop_id=? AND created_at LIKE ? "
            "AND status!='Cancelled'", (sid, d + "%")).fetchone()[0]
        days.append({"label": d[5:], "n": n})
    max_day = max([d["n"] for d in days], default=1) or 1

    return render_template(
        "shop_dashboard.html", shop=shop, orders=orders, stats=shop_stats(sid),
        by_dept=by_dept, max_dept=max_dept, days=days, max_day=max_day,
        statuses=STATUSES, active_status=status)


@app.route("/shop/orders/<int:oid>/status", methods=["POST"])
@login_required("shop")
def update_status(oid):
    new = request.form.get("status")
    if new not in STATUSES:
        abort(400)
    db = get_db()
    cur = db.execute("UPDATE orders SET status=? WHERE id=? AND shop_id=?",
                     (new, oid, g.user["shop_id"]))
    db.commit()
    if cur.rowcount == 0:
        abort(404)
    return redirect(request.referrer or url_for("shop_dashboard"))


@app.route("/shop/settings", methods=["GET", "POST"])
@login_required("shop")
def shop_settings():
    db = get_db()
    sid = g.user["shop_id"]
    if request.method == "POST":
        name = request.form.get("shop_name", "").strip()
        location = request.form.get("location", "").strip()
        bw = parse_price(request.form.get("price_bw"))
        color = parse_price(request.form.get("price_color"))
        if not name or bw is None or color is None:
            flash("Please enter the shop name and valid prices for both B&W and Color.", "error")
        else:
            db.execute(
                "UPDATE shops SET name=?, location=?, price_bw=?, price_color=? WHERE id=?",
                (name, location, bw, color, sid))
            db.commit()
            flash("Shop details saved.", "ok")
            return redirect(url_for("shop_dashboard"))
    shop = db.execute("SELECT * FROM shops WHERE id=?", (sid,)).fetchone()
    return render_template("shop_settings.html", shop=shop)


@app.route("/shop/api/stats")
@login_required("shop")
def api_stats():
    return jsonify(shop_stats(g.user["shop_id"]))


# ----------------------------------------------------------------- files
@app.route("/files/<int:oid>")
@login_required()
def download(oid):
    o = get_db().execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
    if o is None:
        abort(404)
    allowed = (g.user["role"] == "student" and o["student_id"] == g.user["id"]) or \
              (g.user["role"] == "shop" and o["shop_id"] == g.user["shop_id"])
    if not allowed:
        abort(403)
    return send_from_directory(UPLOAD_DIR, o["stored_name"], as_attachment=True,
                               download_name=o["filename"])


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)), debug=False)
